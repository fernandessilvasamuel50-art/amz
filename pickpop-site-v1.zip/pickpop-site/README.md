# pickpop. — Budget-first discovery site (prototype 1)

A responsive, English-language shopping inspiration site with a fun original CSS design, a budget-first idea finder, saved ideas, four categories, and three original editorial articles.

## Try locally

Python (no build dependencies required):

```bash
cd pickpop-site
python -m http.server 8080
```

Visit `http://localhost:8080` in your browser. Do **not** double-click `index.html`: a server is useful for correct absolute paths like `/assets/...`.

## Publish on Netlify for free

1. Create/log into a Netlify account.
2. In Netlify, choose to deploy a site manually (drag-and-drop deployment).
3. Drag the **entire `pickpop-site` folder** (or upload the unzipped folder) to the deploy area.
4. Netlify issues a `*.netlify.app` address; you can later attach a custom domain. Hosting is subject to your provider's current plan limits and policies.
5. Check the pages, mobile layout, policy text, and external links before sharing publicly.

No npm, build step, database, or payment method is needed for the code itself. The project is compatible with any ordinary static-file host serving paths rooted at `/`.

## What really works now

- Free-text keyword search over **20 hand-authored example product ideas**.
- Budget slider, quick budget pills, category filters, price sort.
- Saved ideas using browser local storage, accessible button states.
- Mobile-friendly layout, working navigation, three original articles, privacy/about pages.
- Amazon search links that go to Amazon retail search **without any referral tag**.

## What is intentionally not live

**This is not a live Amazon product search engine.** The data is manually curated *illustrative ideas*, not verified specific Amazon products. All indicated dollar amounts are example *planning budgets*, not actual current Amazon prices. Do not market those amounts as verified Amazon prices. The current links go to ordinary retail searches and **do not generate commissions**. No affiliate status is claimed.

Before real affiliate monetization:

1. Prepare original content that meets Amazon Associates review requirements.
2. Apply to the Amazon.com Associates program using the actual public site.
3. Once permitted, generate compliant **specific tracking links** via Amazon's tools and replace generic search URLs where appropriate.
4. Add disclosures per local applicable requirements and Amazon's Program policies. The Amazon-required statement is: `As an Amazon Associate I earn from qualifying purchases.` **Only use after becoming an Amazon Associate.**
5. For live images, pricing, availability and automatic catalog integration, use only officially authorized Amazon content/tools and comply with their license, caching and display restrictions. Never scrape Amazon product pages.
6. Review the business name, privacy page, contact details, legal requirements, analytics/cookie practices, site URL and terms before launch.

## Customize

- Brand, colors, layout and responsiveness: `assets/css/styles.css` and `index.html`.
- Example catalog, budget, product-search links and filters: `assets/js/app.js` near `const products = [...]`.
- Articles: `guides/*.html`.
- Terms, disclosures and privacy: `about.html`, `privacy.html`.
- Favicon: `assets/favicon.svg`.
- Hosting configuration: `netlify.toml`.

For later iterations, replace the prototype product cards with vetted content and integrate an official API when eligible, while retaining the usable finder, content pages and styling.
